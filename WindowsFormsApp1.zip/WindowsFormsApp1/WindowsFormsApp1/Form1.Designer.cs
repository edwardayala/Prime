﻿
namespace WindowsFormsApp1
{
    partial class PrimeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.asynchronouslyGroupBox = new System.Windows.Forms.GroupBox();
            this.synchronouslyGroupBox = new System.Windows.Forms.GroupBox();
            this.getPrimeLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.nextNumberButton = new System.Windows.Forms.Button();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.asyncResultLabel = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.syncResultLabel = new System.Windows.Forms.Label();
            this.asynchronouslyGroupBox.SuspendLayout();
            this.synchronouslyGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // asynchronouslyGroupBox
            // 
            this.asynchronouslyGroupBox.Controls.Add(this.asyncResultLabel);
            this.asynchronouslyGroupBox.Controls.Add(this.inputTextBox);
            this.asynchronouslyGroupBox.Controls.Add(this.calculateButton);
            this.asynchronouslyGroupBox.Controls.Add(this.getPrimeLabel);
            this.asynchronouslyGroupBox.Location = new System.Drawing.Point(40, 40);
            this.asynchronouslyGroupBox.Name = "asynchronouslyGroupBox";
            this.asynchronouslyGroupBox.Size = new System.Drawing.Size(270, 100);
            this.asynchronouslyGroupBox.TabIndex = 0;
            this.asynchronouslyGroupBox.TabStop = false;
            this.asynchronouslyGroupBox.Text = "Calculate Asyncronously";
            // 
            // synchronouslyGroupBox
            // 
            this.synchronouslyGroupBox.Controls.Add(this.syncResultLabel);
            this.synchronouslyGroupBox.Controls.Add(this.displayLabel);
            this.synchronouslyGroupBox.Controls.Add(this.nextNumberButton);
            this.synchronouslyGroupBox.Location = new System.Drawing.Point(40, 198);
            this.synchronouslyGroupBox.Name = "synchronouslyGroupBox";
            this.synchronouslyGroupBox.Size = new System.Drawing.Size(270, 100);
            this.synchronouslyGroupBox.TabIndex = 1;
            this.synchronouslyGroupBox.TabStop = false;
            this.synchronouslyGroupBox.Text = "Calculate Synchronously";
            // 
            // getPrimeLabel
            // 
            this.getPrimeLabel.AutoSize = true;
            this.getPrimeLabel.Location = new System.Drawing.Point(16, 33);
            this.getPrimeLabel.Name = "getPrimeLabel";
            this.getPrimeLabel.Size = new System.Drawing.Size(76, 15);
            this.getPrimeLabel.TabIndex = 0;
            this.getPrimeLabel.Text = "Get Prime of:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(19, 68);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            // 
            // nextNumberButton
            // 
            this.nextNumberButton.Location = new System.Drawing.Point(19, 67);
            this.nextNumberButton.Name = "nextNumberButton";
            this.nextNumberButton.Size = new System.Drawing.Size(98, 23);
            this.nextNumberButton.TabIndex = 0;
            this.nextNumberButton.Text = "Next Number";
            this.nextNumberButton.UseVisualStyleBackColor = true;
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(94, 30);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 23);
            this.inputTextBox.TabIndex = 2;
            // 
            // asyncResultLabel
            // 
            this.asyncResultLabel.AutoSize = true;
            this.asyncResultLabel.Location = new System.Drawing.Point(118, 72);
            this.asyncResultLabel.Name = "asyncResultLabel";
            this.asyncResultLabel.Size = new System.Drawing.Size(0, 15);
            this.asyncResultLabel.TabIndex = 3;
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Location = new System.Drawing.Point(19, 32);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(0, 15);
            this.displayLabel.TabIndex = 1;
            // 
            // syncResultLabel
            // 
            this.syncResultLabel.AutoSize = true;
            this.syncResultLabel.Location = new System.Drawing.Point(121, 32);
            this.syncResultLabel.Name = "syncResultLabel";
            this.syncResultLabel.Size = new System.Drawing.Size(0, 15);
            this.syncResultLabel.TabIndex = 2;
            // 
            // PrimeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(354, 356);
            this.Controls.Add(this.synchronouslyGroupBox);
            this.Controls.Add(this.asynchronouslyGroupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PrimeForm";
            this.Text = "Prime Numbers";
            this.asynchronouslyGroupBox.ResumeLayout(false);
            this.asynchronouslyGroupBox.PerformLayout();
            this.synchronouslyGroupBox.ResumeLayout(false);
            this.synchronouslyGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox asynchronouslyGroupBox;
        private System.Windows.Forms.Label asyncResultLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label getPrimeLabel;
        private System.Windows.Forms.GroupBox synchronouslyGroupBox;
        private System.Windows.Forms.Label syncResultLabel;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Button nextNumberButton;
    }
}


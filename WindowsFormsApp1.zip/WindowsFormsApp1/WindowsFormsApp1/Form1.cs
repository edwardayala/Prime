﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PrimeForm : Form
    {
        private int n2 = 0;
        private int j = 1;
        int count = 0;

        public PrimeForm()
        {
            InitializeComponent();
        }
        private async void calculateButton_Click(object sender, EventArgs e)
        {
            int number = int.Parse(inputTextBox.Text);
            asyncResultLabel.Text = "Calculating...";

            Task<long> PrimeTask = Task.Run(() => Prime(number));

            await PrimeTask;

            asyncResultLabel.Text = PrimeTask.Result.ToString();
        }

        private void nextNumberButton_Click(object sender, EventArgs e)
        {
            bool check = false;
            
            while (!check)
            {
                j++;
                check = isPrime(j);
            }
            n2 = n2 + j;
            count++;

            displayLabel.Text = $"Prime of {count}:";
            syncResultLabel.Text = n2.ToString();
        }

        public long Prime(long n)
        {
            long totalPrime = 0;
            long countPrime = n;

            int x = 0;

            int i = 0;
            
            while (x < countPrime)
            {
                bool prime = isPrime(i);
                if (prime)
                {
                    totalPrime = totalPrime + i;
                    x++;
                }
                i++;
            }
            return totalPrime;
        }

        public bool isPrime(int number)
        {
            if ((number & 1) == 0)
            {
                if (number == 2)
                    return true;
                else
                    return false;
            }
            for (int i = 3; (i * i) <= number; i += 2)
            {
                if ((number % i) == 0)
                    return false;
            }
            return number != 1;
        }
    }
}
